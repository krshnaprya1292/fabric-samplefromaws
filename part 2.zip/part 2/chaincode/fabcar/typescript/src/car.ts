/*
 * SPDX-License-Identifier: Apache-2.0
 */

export class Car {
    public docType?: string;
    public color: string;
    public make: string;
    public model: string;
    public owner: string;
}
